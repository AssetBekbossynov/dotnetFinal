﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Final.Models;


namespace Final
{
    public class TicketContext : DbContext
    {

        public TicketContext(DbContextOptions<TicketContext> options)
            : base(options)
        { }

        public DbSet<Client> Clients { get; set; }
        public DbSet<Flight> Flights { get; set; }
        public DbSet<Place> Places { get; set; }
        public DbSet<Sale> Sales { get; set; }
        public DbSet<SaleDetail> SaleDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Place>().ToTable("Place");
            modelBuilder.Entity<Sale>().ToTable("Sale");
            modelBuilder.Entity<SaleDetail>().ToTable("SaleDetail");
            modelBuilder.Entity<Flight>().ToTable("Flight");
            modelBuilder.Entity<Client>().ToTable("Client");
        }
    }
}
