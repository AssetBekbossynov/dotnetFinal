﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Final.Models;

namespace Final
{
    public class DBInitializer
    {
        public static void Initialize(TicketContext context)
        {
            context.Database.EnsureCreated();
            if (context.Flights.Any()) { return; }
            var fligts = new Flight[]
            {
                new Flight{Id = 1, Name = "TSE", Price = 30000 },
                new Flight{Id = 2, Name = "TDK", Price = 15000 },
                new Flight{Id = 3, Name = "ATE", Price = 35000 },
            };

            foreach (Flight f in fligts)
            {
                context.Flights.Add(f);
            }
            context.SaveChanges();

            var places = new Place[]
            {
                new Place{Id = 1, FlightId = 1, Name = "A1", Price = 31000},
                new Place{Id = 2, FlightId = 1, Name = "A2", Price = 30000},
                new Place{Id = 3, FlightId = 1, Name = "A3", Price = 30000},
                new Place{Id = 4, FlightId = 1, Name = "A4", Price = 30000},
                new Place{Id = 5, FlightId = 1, Name = "A5", Price = 32000},

                new Place{Id = 6, FlightId = 2, Name = "A1", Price = 14000},
                new Place{Id = 7, FlightId = 2, Name = "A2", Price = 15000},
                new Place{Id = 8, FlightId = 2, Name = "A3", Price = 15000},
                new Place{Id = 9, FlightId = 2, Name = "A4", Price = 15000},
                new Place{Id = 10, FlightId = 2, Name = "A5", Price = 12000},

                new Place{Id = 11, FlightId = 3, Name = "A1", Price = 34000},
                new Place{Id = 12, FlightId = 3, Name = "A2", Price = 35000},
                new Place{Id = 13, FlightId = 3, Name = "A3", Price = 35000},
                new Place{Id = 14, FlightId = 3, Name = "A4", Price = 35000},
                new Place{Id = 15, FlightId = 3, Name = "A5", Price = 32000}
         
            };

            foreach(Place p in places)
            {
                context.Places.Add(p);
            }
            context.SaveChanges();
        }

    }
}
