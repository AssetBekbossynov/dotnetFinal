﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final.Models
{
    public class Place
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
        
        public int FlightId { get; set; }
    }
}
