﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final.Models
{
    public class SaleDetail
    {
        public int Id { get; set; }
        public int PlaceId { get; set; }
        public int SaleId { get; set; }
    }
}
