﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final.Models
{
    public class Report1
    {
        public DateTime SaleDate { get; set; }
        public string PlaceName { get; set; }
        public string FlightName { get; set; }
    }
}
