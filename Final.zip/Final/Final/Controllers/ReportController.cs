﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Final.Models;

namespace Final.Controllers
{
    [Produces("application/json")]
    [Route("api/Report")]
    public class ReportController : Controller
    {

        private readonly TicketContext _context;

        public ReportController(TicketContext context)
        {
            _context = context;
        }

        // GET: api/Report
        [HttpGet]
        public IEnumerable<Report1> Get(DateTime startDate, DateTime endDate)
        {
            var saleDetailSale = _context.SaleDetails.Join(_context.Sales, x => x.SaleId, y => y.Id, (x, y) => new
            {
                x.PlaceId,
                y.ClientId,
                y.SaleDate
            }).Join(_context.Places, x => x.PlaceId, y => y.Id, (x, y) => new
            {
                x.SaleDate,
                x.ClientId,
                y.FlightId,
                y.Name,
                y.Price
            }).Join(_context.Flights, x => x.FlightId, y => y.Id, (x, y) => new Report1
            {
                SaleDate = x.SaleDate,
                PlaceName = x.Name,
                FlightName = y.Name
            }).Where(x=>x.SaleDate <= endDate && x.SaleDate >= startDate)
            .ToList();
            saleDetailSale.GroupBy(x => x.FlightName).ToList();
                        
            return saleDetailSale;
        }

        [HttpGet("report2", Name = "Get")]
        public void Get()
        {
            
        }

        // GET: api/Report/5
        /*[HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }*/
    }
}
