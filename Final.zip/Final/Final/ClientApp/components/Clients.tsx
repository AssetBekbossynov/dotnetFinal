﻿import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import 'isomorphic-fetch';

interface ClientsState {
    clients: ClientsForecast[];
    loading: boolean;
}

export class Clients extends React.Component<RouteComponentProps<{}>, ClientsState> {
    constructor() {
        super();
        this.state = { clients: [], loading: true };

        fetch('api/Clients')
            .then(response => response.json() as Promise<ClientsForecast[]>)
            .then(data => {
                this.setState({ clients: data, loading: false });
            });
    }

    public render() {
        let contents = this.state.loading
            ? <p><em>Loading...</em></p > : Clients.renderForecastsTable(this.state.clients);

        return <div>
            <h1>Weather forecast </h1>
            < p > This component demonstrates fetching data from the server.</p>
            {contents}
        </div>;
    }

    private static renderForecastsTable(forecasts: ClientsForecast[]) {
        return <table className='table'>
            <thead>
                <tr>
                    <th>ID</th>
                    <th> Name </th>
                    <th> LastName </th>
                </tr>
            </thead>
            <tbody>
                {
                    forecasts.map(forecast =>
                        <tr key={forecast.Id} >
                            <td> {forecast.Id} </td>
                            <td> {forecast.Name} </td>
                            <td> {forecast.LastName} </td>
                        </tr>
                    )
                }
            </tbody>
        </table>;
    }
}

interface ClientsForecast {
    Id: number;
    Name: string;
    LastName: string;
}
