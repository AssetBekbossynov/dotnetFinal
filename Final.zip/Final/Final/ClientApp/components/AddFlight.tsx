﻿import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import 'isomorphic-fetch';
interface MyComponentProps {
    addFlight: any,
    /* declare your component's props here */
}

interface MyComponentState {
    id: any;
    name: any;
    price: any;
}

export class AddFlight extends React.Component<any, any> {
    //handleChange: any;
    constructor(props: any) {
        super(props);
        this.state = {
            id: '',
            name: '',
            price: '',
        };
    }

    public handleChangeId = (e: any) => {
        this.setState({
            id: e.target.value,
        })

    }

    public handleChangeName = (e: any) => {
        this.setState({
            name: e.target.value,
        })

    }

    public handleChangePrice = (e: any) => {
        this.setState({ 
            price: e.target.value,
        })
    }

    public addFlight = (flight: any) => {
        this.props.addFlight({
            'id': this.state.id,
            'name': this.state.name,
            'price': this.state.price
        });
        this.setState({
            id: '',
            name: '',
            price: ''
        })
    }

    public render() {
        return (
            <div>
                <input className="input" type="number" value={this.state.id} onChange={this.handleChangeId} />
                <input className="input" type="text" value={this.state.name} onChange={this.handleChangeName} />
                <input className="input" type="number" value={this.state.price} onChange={this.handleChangePrice} />
                <button className="button" onClick={this.addFlight}>Add</button>
            </div>
        );
    }
}