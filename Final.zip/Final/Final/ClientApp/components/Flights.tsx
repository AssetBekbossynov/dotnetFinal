﻿import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import 'isomorphic-fetch';
import { AddFlight } from './AddFlight'
import { DeleteFlight } from './DeleteFlight'

interface FlightsState {
    flights: FlightsForecast[];
    loading: boolean;
}

export class Flights extends React.Component<RouteComponentProps<{}>, FlightsState> {
    constructor() {
        super();
        this.state = { flights: [], loading: true };

        fetch('api/Flights/')
            .then(response => response.json() as Promise<FlightsForecast[]>)
            .then(data => {
                this.setState({ flights: data, loading: false });
            });
        console.log("Here");

        console.log(this.state.flights);
    }


    loadFlights = () => {
        fetch("api/Flights/")
            .then(res => res.json())
            .then(res => this.setState({
                flights: res
            }));
        console.log(this.state.flights)
    };


    addFlight = (flight: any) => {

        fetch("api/Flights/", {
            method: "post",
            body: JSON.stringify(flight),
            headers: {
                'Content-Type': 'application/json'
            },
        })//.then(res => res.json())
            .then(res => console.log(res))
            .then(res => this.loadFlights())
    };

    deleteFlight = (flightId: any) => {
        fetch("api/Flights/" + flightId, {
            method: "delete",
        }).then(res => this.loadFlights())
    }

    public render() {
        let contents = this.state.loading
            ? <p><em>Loading...</em></p > : Flights.renderForecastsTable(this.state.flights);

        return <div>
            <h1>Weather forecast </h1>
            < p > This component demonstrates fetching data from the server.</p>
            <AddFlight addFlight={this.addFlight} />
            <DeleteFlight deleteFlight={this.deleteFlight} />
            {contents}
        </div>;
    }

    private static renderForecastsTable(forecasts: FlightsForecast[]) {
        return <table className='table'>
            <thead>
                <tr>
                    <th> ID </th>
                    <th> Name </th>
                    <th> Price </th>
                </tr>
            </thead>
            <tbody>
                {
                    forecasts.map(forecast =>
                        <tr key={forecast.Id} >
                            <td>{forecast.Id} </td>
                            <td> {forecast.Name} </td>
                            <td> {forecast.Price} </td>
                        </tr>
                    )
                }
            </tbody>
        </table>;
    }
}

interface FlightsForecast {
    Id: number;
    Name: string;
    Price: number;
}
