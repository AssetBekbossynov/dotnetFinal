﻿import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import 'isomorphic-fetch';

interface PlacesState {
    places: PlacesForecast[];
    loading: boolean;
}

export class Places extends React.Component<RouteComponentProps<{}>, PlacesState> {
    constructor() {
        super();
        this.state = { places: [], loading: true };

        fetch('api/Places')
            .then(response => response.json() as Promise<PlacesForecast[]>)
            .then(data => {
                this.setState({ places: data, loading: false });
            });
    }

    public render() {
        let contents = this.state.loading
            ? <p><em>Loading...</em></p >: Places.renderForecastsTable(this.state.places);

        return<div>
            <h1>Weather forecast </h1>
                < p > This component demonstrates fetching data from the server.</p>
                {contents}
        </div>;
    }

    private static renderForecastsTable(forecasts: PlacesForecast[]) {
        return <table className='table'>
            <thead>
                <tr>
                    <th>ID</th>
                    <th> Name </th>
                    <th> Price </th>
                    <th> FlightId </th>
                </tr>
            </thead>
            <tbody>
            {
                    forecasts.map(forecast =>
                        <tr key={forecast.Id} >
                            <td>{forecast.Id} </td>
                            <td> {forecast.Name} </td>
                            <td> {forecast.Price} </td>
                            <td> {forecast.FlightId} </td>
                        </tr>
                )
            }
            </tbody>
            </table>;
    }
}

interface PlacesForecast {
    Id : number;
    Name : string;
    Price: number;
    FlightId: number;
}
