﻿import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import 'isomorphic-fetch';

interface SalesState {
    sales: SalesForecast[];
    loading: boolean;
}

export class Sales extends React.Component<RouteComponentProps<{}>, SalesState> {
    constructor() {
        super();
        this.state = { sales: [], loading: true };

        fetch('api/Sales')
            .then(response => response.json() as Promise<SalesForecast[]>)
            .then(data => {
                this.setState({ sales: data, loading: false });
            });
    }

    public render() {
        let contents = this.state.loading
            ? <p><em>Loading...</em></p > : Sales.renderForecastsTable(this.state.sales);

        return <div>
            <h1>Weather forecast </h1>
            < p > This component demonstrates fetching data from the server.</p>
            {contents}
        </div>;
    }

    private static renderForecastsTable(forecasts: SalesForecast[]) {
        return <table className='table'>
            <thead>
                <tr>
                    <th>ID</th>
                    <th> Date </th>
                    <th> ClientId </th>
                </tr>
            </thead>
            <tbody>
                {
                    forecasts.map(forecast =>
                        <tr key={forecast.Id} >
                            <td> {forecast.Id} </td>
                            <td> {forecast.Date} </td>
                            <td> {forecast.ClientId} </td>
                        </tr>
                    )
                }
            </tbody>
        </table>;
    }
}

interface SalesForecast {
    Id: number;
    Date: Date;
    ClientId: number;
}
