﻿import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import 'isomorphic-fetch';

interface MyComponentProps {
    deleteFlight: any,
    /* declare your component's props here */
}

interface MyComponentState {
    id: any;
}

export class DeleteFlight extends React.Component<any, any> {
    //handleChange: any;
    constructor(props: any) {
        super(props);
        this.state = {
            id: '',
        };
    }

    public handleChange = (e: any) => {
        this.setState({
            id: e.target.value,
        })
    }

    public deleteFlight = () => {
        this.props.deleteFlight(this.state.id);
        this.setState({
            id: ''
        })
    }

    public render() {
        return (
            <div>
                <input className="input" type="number" value={this.state.id} onChange={this.handleChange} />
                <button className="button" onClick={this.deleteFlight}>Delete</button>
            </div>
        );
    }
}